"""
Exercise 6.1 Managing Files
Ex6_1.py
"""

import sys

def main():
    file = r'C:\Course\1905\Data\flights.csv'
    search_flight = '1587'

main()
