"""
Exercise 6.1 Managing Files
Ex6_1_EndPoint.py
"""

import sys

def main():
    file = r'C:\Course\1905\Data\flights.csv'
    search_flight = '1587'
    outfile = r'search_flights.csv'
    with open(file, 'r') as inf:
        with open(outfile, 'w') as outf:
            for line in inf:
                if line[:4] == search_flight:
                    outf.write(line)

main()
