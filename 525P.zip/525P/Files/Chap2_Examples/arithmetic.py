# Arithmetic Typing Functions
num = '4'
print(type(num))

int_num = int(num)
flt_num = float(num)
print(type(int_num))

print(int_num * flt_num)

# The math Module
import math
print(math.sqrt(16))
print(math.factorial(4))
