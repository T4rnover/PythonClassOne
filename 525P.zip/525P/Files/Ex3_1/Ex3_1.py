"""
Exercise 3.1 Collections and Slicing
Ex3_1.py
"""

# Part A
codelist = ['HNL', 'ITO', 'LHR', 'LGA', 'GCM', 'MSY', 'LAX']
flightlist = ['HNL', 'HKG', '2022-01-03 16:00', '2022-01-03 20:00', 99.95, 4]

# departcity = flightlist[0]
# arrivecity = flightlist[1]
# departdaytime = flightlist[2]
# arrivedaytime = flightlist[3]
# cost = flightlist[4]
# code = flightlist[5]

# Part A
# Print the first two codes
print(codelist[:2])

# Print the last two codes
print(codelist[-2:])

# Use sequence unpacking to assign the list contents to separate variables
departcity, arrivecity, departdaytime, arrivedaytime, *_ = flightlist

# Print the departcity, arrivecity, departdaytime, and arrivedaytime
print(f'Departure city: {departcity}')
print(f'Arrival city: {arrivecity}')
print(f'Departure date and time: {departdaytime}')
print(f'Arrival date and time: {arrivedaytime}')

# Reverse the contents of codelist
codelist.reverse()

# Print the reversed codelist
print(codelist)

# Sort codelist in ascending order
codelist.sort()

# Print the sorted codelist
print(codelist)

# Assign codelist to aptlist
aptlist = codelist

# Use the pop() method to remove the last element from aptlist
aptlist.pop()

# Print aptlist and codelist
print('aptlist:', aptlist)
print('codelist:', codelist)

# Test if aptlist and codelist have a shared reference
if aptlist is codelist:
    print("aptlist and codelist have a shared reference.")
else:
    print("aptlist and codelist do not have a shared reference.")
    
# Use the list() function to create a copy of codelist and assign it to aptlist
aptlist = list(codelist)

# Use the pop() method to remove the last element from aptlist
aptlist.pop()

# Print aptlist and codelist
print('aptlist:', aptlist)
print('codelist:', codelist)

# Use slicing to create a copy of codelist and assign it to aptlist
aptlist = codelist[:]

# Test if aptlist and codelist have identical contents
if aptlist == codelist:
    print("aptlist and codelist have identical contents.")
else:
    print("aptlist and codelist do not have identical contents.")

# Test if aptlist and codelist have a shared reference
if aptlist is codelist:
    print("aptlist and codelist have a shared reference.")
else:
    print("aptlist and codelist do not have a shared reference.")
    
# Insert 'ABC' before the first element of codelist
codelist.insert(0, 'ABC')

# Append 'XYZ' to the end of codelist
codelist.append('XYZ')

# Print the updated codelist
print(codelist)

# Create a tuple from codelist and assign it to codetupe
codetupe = tuple(codelist)

# Test if the length of codelist is equal to the length of codetupe
if len(codelist) == len(codetupe):
    print("The length of codelist is equal to the length of codetupe.")
else:
    print("The length of codelist is not equal to the length of codetupe.")
    
# Try to use the append() method with a tuple
try:
    codetupe.append('XYZ')
except AttributeError:
    print("Cannot use the append() method with a tuple.")

# Try to use the sort() method with a tuple
try:
    codetupe.sort()
except AttributeError:
    print("Cannot use the sort() method with a tuple.")

# Try to use the pop() method with a tuple
try:
    codetupe.pop()
except AttributeError:
    print("Cannot use the pop() method with a tuple.")
    
"""The `sorted()` function in Python is used to sort the elements of an iterable (like a list, tuple, or string) in a specific order (either ascending or descending).

The function returns a new sorted list from the elements of any iterable, not just lists. The original iterable is not changed.

Here is the basic syntax of the `sorted()` function:

```python
sorted(iterable, *, key=None, reverse=False)
```

The `reverse` parameter is optional. If set to `True`, then the iterable is sorted in descending order. If it's `False` (which is the default), then the iterable is sorted in ascending order.

The `key` parameter is also optional and expects a function to be passed to it. This function serves as a key or a basis of sort comparison.

For example:

```python
numbers = [1, 3, 4, 2]
sorted_numbers = sorted(numbers)  # [1, 2, 3, 4]
sorted_numbers_desc = sorted(numbers, reverse=True)  # [4, 3, 2, 1]
```
"""

# Sort codetupe in reverse order and convert the returned value into a tuple
sorted_codetupe = tuple(sorted(codetupe, reverse=True))

# Print sorted_codetupe
print(sorted_codetupe)
