# Creating a Module
import circles

rad = 1.0
ar = circles.area(rad)
print('circle is radius {} area {}'.format(rad, ar))