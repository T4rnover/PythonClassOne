import os
import sys

work_dir = r'c:/Course/525P/Files/Chap5_Examples/work'
if not os.path.isdir(work_dir):
    os.mkdir(work_dir)
    print(work_dir, 'created')
else:
    print(work_dir, 'already exists')

data_dir = r'c:/Course/525P/Files/Chap5_Examples/data'
if os.path.isdir(data_dir):
    print('contents of', data_dir)
    for name in os.listdir(data_dir):
        print('\t', name)
else:
    print(data_dir, 'does not exist, exiting now')
    sys.exit(1)