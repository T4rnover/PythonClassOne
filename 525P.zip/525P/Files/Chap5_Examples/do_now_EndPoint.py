import os
import shutil
import sys

work_dir = r'c:/Course/525P/Files/Chap5_Examples/work'
if not os.path.isdir(work_dir):
    os.mkdir(work_dir)
    print(work_dir, 'created')
else:
    print(work_dir, 'already exists')

data_dir = r'c:/Course/525P/Files/Chap5_Examples/data'
if os.path.isdir(data_dir):
    print('contents of', data_dir)
    for name in os.listdir(data_dir):
        print('\t', name)
else:
    print(data_dir, 'does not exist, exiting now')
    sys.exit(1)

for name in os.listdir(data_dir):
    full_name = data_dir + '/' + name
    if os.path.isfile(full_name):
        shutil.copy2(full_name, work_dir)

print('the contents of', work_dir)
for name in os.listdir(work_dir):
    print('\t', name)