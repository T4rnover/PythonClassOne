from math import pi

def area(radius):
    return pi * radius ** 2

def diameter(radius):
    return radius * 2