"""
    os_examples.py
"""

import os
import shutil

# Examine environment variables
for key, value in os.environ.items():
    print(key, '--->', value)

# Directory Handling
basedir = 'C:/Course/525P/Files/Chap5_Examples'
os.chdir(basedir)
print('current directory is now', os.getcwd())
print('listing contents\n', os.listdir())

file = basedir + '/os_examples.py'

# Testing
print('testing for', file)
if os.path.exists(file):
    print('the name', file, 'exists ', end='')
    if os.path.isfile(file):
        print('is a file to be copied')
        new_dir = basedir + '/temp'
        if not os.path.exists(new_dir):
            os.mkdir(new_dir)
            shutil.copy2(file, new_dir )
    elif os.path.isdir(file):
        print('is a directory')
    else:
        print('is not a file or directory')
else:
    print(file, 'not found')
