# The import Statement
import math
rad = 1
circ = 2 * rad * math.pi
print('circumference is', circ)

# The import as Statement
import math as m
rad = 1
circ = 2 * rad * m.pi
print('circumference is', circ)

# from Statement
from math import pi
rad = 1
cicr = 2 * rad * pi
print('circumference is', circ)
