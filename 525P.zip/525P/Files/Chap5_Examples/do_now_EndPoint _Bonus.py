import os
import shutil
import sys

work_dir = r'c:/Course/525P/Files/Chap5_Examples/work'
if not os.path.isdir(work_dir):
    os.mkdir(work_dir)
    print(work_dir, 'created')
else:
    print(work_dir, 'already exists')

data_dir = r'c:/Course/525P/Files/Chap5_Examples/data'
if os.path.isdir(data_dir):
    print('contents of', data_dir)
    for name in os.listdir(data_dir):
        print('\t', name)
else:
    print(data_dir, 'does not exist, exiting now')
    sys.exit(1)

err_dir = r'c:/Course/525P/Files/Chap5_Examples/errors'
if not os.path.isdir(err_dir):
    os.mkdir(err_dir)
    print(err_dir, 'created')
else:
    print(err_dir, 'already exists')

for name in os.listdir(data_dir):
    full_name = data_dir + '/' + name
    if os.path.isfile(full_name):
        print('full name', full_name, 'LAST 3', full_name[-3:])
        if full_name[-3:] == 'csv':
            shutil.copy2(full_name, work_dir)
        else:
            shutil.copy2(full_name, err_dir)

print('the contents of', work_dir)
for name in os.listdir(work_dir):
    print('\t', name)

print('the contents of', err_dir)
for name in os.listdir(err_dir):
    print('\t', name)