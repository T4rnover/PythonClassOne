greeting = 'Good Day'
print(greeting)