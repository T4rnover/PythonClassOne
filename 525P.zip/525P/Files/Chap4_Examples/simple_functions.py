# Simple Function Example
def print_one():
    num = 1
    print('the value of num is', num)

def print_two():
    num = 2
    print('the value of num is', num)

print_one()
print_two()
print('The print_one object', print_one)

# Passing Data Into a Function
def printposit(depart, arrive):
    print('depart and arrive by position:', depart, arrive)

printposit('NRT', 'HNL')

# Keyword Parameters
def printkey(depart, arrive):
    print('depart and arrive by keyword:', depart, arrive)

def printdef(depart='LAX', arrive='HNL'):
    print('depart and arrive defaults:', depart, arrive)

printkey(arrive='HNL', depart='NRT')
printdef(depart='AMS')

# Parameters and Scope
def increment(number):
    number += 1
    print('function number is', number)

number = 5
increment(number)
print('global number is', number)

# Enclosed Functions
def logdata():
    def print_header():
        print('Beginning status')

    def print_footer():
        print('Ending status')

    print_header()
    print('Processing...')
    print_footer()

logdata()


# Scope
var = 'global'
def fun1():
    var = 'enclosing'

    def fun2():
        var = 'local'
        print('enclosed var:', var)

    fun2()
    print('enclosing var:', var)

fun1()
print('global var:', var)

# Function return Example
def addtwice(num):
    print(num + num)

ans = addtwice(3)
print('ans is', ans)

# Functions and Polymorphism
def twice(parm):
    return parm + parm

print('Try twice()', twice(5.5))
print('Try twice()', twice(['a', 'list']))
# The following will cause a Type exception to be raised
# print(twice({'firstname': 'Robert', 'lastname': 'Johnson'}))
