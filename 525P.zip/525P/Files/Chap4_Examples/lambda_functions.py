# The Lambda Expression
def square(x):
    return x ** 2

cube = lambda x: x ** 3
print(square(5))
print(cube(5))

# The sorted() Function
costs = (('YYZ', '35'), ('HNL', '100'), ('NRT', '52.5'))
print(sorted(costs))
print(sorted(costs, key=lambda p: p[1]))
print(sorted(costs, key=lambda p: float(p[1])))
