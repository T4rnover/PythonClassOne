# Using Loops and Iterators for File Access
with open('C:/Course/525P/Data/simple.txt', 'r') as infile:
    for dataline in infile:
        print(dataline.rstrip())
