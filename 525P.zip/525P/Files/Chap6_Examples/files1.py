# Reading a Text File Example

infile = open('C:/Course/1905/Data/simple.txt', 'r')
print(infile.readline().rstrip())
print(infile.readlines())
infile.close()