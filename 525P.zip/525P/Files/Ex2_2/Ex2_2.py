"""
Exercise 2.2 Strings and if.
Ex2_2.py
"""

# Part A
plane1 = 'Boeing767 6670'
plane2 = 'CRJ        950'
# 2.2 Number 2 Display the plane type and 
#flight range for each planeN string
#
# Extract the plane type and flight range from the strings
print ("--------Number 2")
plane1_type = plane1[:9].strip()  # The plane type is in the first 9 characters
plane1_range = int(plane1[9:].strip())  # The flight range is in the remaining characters

plane2_type = plane2[:9].strip()  # The plane type is in the first 9 characters
plane2_range = int(plane2[9:].strip())  # The flight range is in the remaining characters

# Print the extracted values
print(f'Plane 1 type: {plane1_type}, range: {plane1_range} miles')
print(f'Plane 2 type: {plane2_type}, range: {plane2_range} miles')
# 2.2 Number 3 Concatenate the plane types and sum the plane ranges
print ("--------Number 3")
plane_types = plane1_type + ', ' + plane2_type
plane_ranges = int(plane1_range) + int(plane2_range)

# Print the results
print(f'Plane types: {plane_types}')
print(f'Total range: {plane_ranges} miles')


print ("--------Number 4")

# Part B
plane1 = 'Boeing767,6670'
plane2 = 'CRJ,950'

# Find the index of the comma in each string
comma_index1 = plane1.find(',')
comma_index2 = plane2.find(',')

# Use string slicing to extract the plane type and range
plane1_type = plane1[:comma_index1]
plane1_range = plane1[comma_index1+1:]

plane2_type = plane2[:comma_index2]
plane2_range = plane2[comma_index2+1:]

# Print the extracted values
print(f'Plane 1 type: {plane1_type}, range: {plane1_range} miles')
print(f'Plane 2 type: {plane2_type}, range: {plane2_range} miles')

# Part C
print ("--------Number 5")
if plane1_type.isupper():
    print(f'Plane 1 type {plane1_type} is completely uppercase')

if plane2_type.isupper():
    print(f'Plane 2 type {plane2_type} is completely uppercase')
print ("--------Number 6")

# Extract the plane type and flight range from the strings
plane1_type, plane1_range = plane1.split(',')
plane2_type, plane2_range = plane2.split(',')

# Convert ranges to integers
plane1_range = int(plane1_range)
plane2_range = int(plane2_range)

# Check if plane type ends with a digit
if plane1_type[-1].isdigit():
    print(f'Plane 1 type {plane1_type} ends with a digit')

if plane2_type[-1].isdigit():
    print(f'Plane 2 type {plane2_type} ends with a digit')

# Determine which plane has the greater range
if plane1_range > plane2_range:
    print(f'Plane 1 has a greater range')
elif plane1_range < plane2_range:
    print(f'Plane 2 has a greater range')
else:
    print(f'Both planes have the same range')

# Part D
print ("--------Number 7, 8 and 9")
print("Python is Guido's invention")
print('They say, "Python is Guido\'s invention."')

airport1 = "HNL,Honolulu"
airport2 = "LHR,London/Heathrow"
airport3 = "ARN,Stockholm/Arlanda"
airport4 = "HKG,Hong Kong"
airport5 = "GCM,Grand Cayman BWI"

print ("--------Number 10")
# Extract the airport codes from the CSV strings
airport1_code = airport1.split(',')[0]
airport2_code = airport2.split(',')[0]
airport3_code = airport3.split(',')[0]
airport4_code = airport4.split(',')[0]
airport5_code = airport5.split(',')[0]

# Create a new CSV string of all airport codes
airport_codes = f'"{airport1_code}","{airport2_code}","{airport3_code}","{airport4_code}","{airport5_code}"'

# Print the new CSV string
print(airport_codes)
print ("--------Number 11")
# Define a list of the airport strings
airports = [airport1, airport2, airport3, airport4, airport5]

# Initialize an empty list to hold the city names
city_names = []

# Loop over the airport strings
for airport in airports:
    # Split the string into two parts at the comma
    code, city = airport.split(',')
    # Add the city name to the list, surrounded by double quotation marks
    city_names.append(f'"{city}"')

# Join the city names into a new CSV string
city_names_csv = ','.join(city_names)

# Print the new CSV string
print(city_names_csv)
print ("--------Number 12")
# Apply the split() method to airport1
result = airport1.split(',')

# Print the result
print(result)