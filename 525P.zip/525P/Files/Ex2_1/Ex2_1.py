"""
Exercise 2.1 Arithmetic and Numeric Types
Ex2_1.py
"""

print('This is exercise 2.1')
print("-------Part A")
# Part A
num1 = int('5')
num2 = int('9')
#Convert the strings into numbers 
#and display the result of 
#num1 / num2.

print("Division Result is:",num1/num2)
print("-------Part B")
# Part B
paris_temp = float('25')
honolulu_temp = float('81')
freezing = 32.0

print("paris convert",paris_temp*(9/5)+32)
print("honolulu convert",(honolulu_temp-32)*(5/9))
# Part C
print("-------Part C")
price = float('199.95')  # Convert the price to a float

discount_small = .05
discount_med = .10
discount_big = .15

# Calculate the new prices after applying the discounts
price_small = price * (1 - discount_small)
price_med = price * (1 - discount_med)
price_big = price * (1 - discount_big)

# Display the new prices
print(f'Price after small discount: {price_small}')
print(f'Price after medium discount: {price_med}')
print(f'Price after big discount: {price_big}')
print("------- Extra One")
# Define the distances and times for the two flights
distance1_miles = 305
time1_minutes = 62

distance2_miles = 525
time2_minutes = 91

# Convert times to hours
time1_hours = time1_minutes / 60
time2_hours = time2_minutes / 60

# Calculate the speeds in miles per hour
speed1_mph = distance1_miles / time1_hours
speed2_mph = distance2_miles / time2_hours

# Convert distances to kilometers
distance1_km = distance1_miles * 1.60934
distance2_km = distance2_miles * 1.60934

# Calculate the speeds in kilometers per hour
speed1_kph = distance1_km / time1_hours
speed2_kph = distance2_km / time2_hours

# Calculate the average speed in miles per hour
average_speed_mph = (distance1_miles + distance2_miles) / (time1_hours + time2_hours)

# Print the results
print(f'Speed of first flight: {speed1_mph} mph ({speed1_kph} kph)')
print(f'Speed of second flight: {speed2_mph} mph ({speed2_kph} kph)')
print(f'Average speed of both flights: {average_speed_mph} mph')
print("------- Extra Two")
import math

# Define the area of the circle
area_miles = 7.5

# Calculate the radius of the circle
radius_miles = math.sqrt(area_miles / math.pi)

# Print the radius
print(f'The radius of the circle is: {radius_miles} miles')